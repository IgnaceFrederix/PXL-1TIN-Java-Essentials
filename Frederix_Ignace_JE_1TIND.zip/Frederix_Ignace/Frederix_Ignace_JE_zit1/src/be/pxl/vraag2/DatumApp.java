package be.pxl.vraag2;
//Ignace frederix
public class DatumApp {

	public static void main(String[] args) {
		 new Datum();

	}

}
