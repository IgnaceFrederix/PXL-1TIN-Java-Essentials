package be.pxl.vraag2;


import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

import javax.swing.*;

public class Left  extends JFrame  {
	//Ignace frederix
	
	private JLabel links;
	public JList <LocalDate>datums; 
	
	
	
	
	public Left(){
		initComponents();
		layoutComponets();
		initListeners();
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		
		
	}
	
	private void initComponents(){
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	LocalDate[] = 	
		
	
		
	}
	private void layoutComponets(){

		
	}
	
	private void initListeners(){
		
	}
	
	
	

	
	
	

}
