package be.pxl.vraag1;
//Ignace frederix
public interface Saleable {
	public double calculatePrice();

}
