package be.pxl.vraag1;
//Ignace frederix
public interface Printable {
	
	public void print();

}
