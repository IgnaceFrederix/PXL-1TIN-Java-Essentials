package be.pxl.vraag1;

/*
    Daan Vankerkom
    1 TIN J
 */
public interface Interagerend {
    void interageer(WereldObject o);
}
