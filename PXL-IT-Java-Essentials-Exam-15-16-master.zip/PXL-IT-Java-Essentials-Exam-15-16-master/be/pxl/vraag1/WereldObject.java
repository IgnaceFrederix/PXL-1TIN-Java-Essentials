package be.pxl.vraag1;

/*
    Daan Vankerkom
    1 TIN J
 */
public abstract class WereldObject {
}
