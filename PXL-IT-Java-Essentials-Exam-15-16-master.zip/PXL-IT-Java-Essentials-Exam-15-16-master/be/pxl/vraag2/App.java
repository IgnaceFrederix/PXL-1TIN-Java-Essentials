package be.pxl.vraag2;

/*
    Daan Vankerkom
    1 TIN J
 */
public class App {

    public static void main(String[] args) {
        new Vraag2();
    }

}
