package be.pxl.vraag1;

/*
 	Ignace Frederix
 	1TING
 */
public interface Verkoopbaar {
	public default double berekenPrijs(){
		return 0;
		
	}
}
