package be.pxl.vraag1;

public interface Vervalbaar {
	
	/*
	 * Ignace Frederix
	 * 1TING
	 */
	public default boolean IsVervallen(){
		return false;
		
		
	}
}
