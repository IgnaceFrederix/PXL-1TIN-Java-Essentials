package be.pxl.vraag3;
/*
 * Ignace Frederix
 * 1TING
 */
public enum Element {

	VUUR,
	AARDE,
	WATER,
	LUCHT;
}
