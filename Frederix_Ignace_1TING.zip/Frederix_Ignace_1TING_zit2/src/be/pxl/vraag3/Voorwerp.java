package be.pxl.vraag3;

public class Voorwerp {
	private Element e;

	public Voorwerp(Element e){
		this.e = e;
	}

	public Element getE() {
		return e;
	}
	
	
}
