package be.pxl.vraag2;

public class Vraag2App {

	public static void main(String[] args) {
		int aantal;
		
		new vraag2(aantal);

	}

}
